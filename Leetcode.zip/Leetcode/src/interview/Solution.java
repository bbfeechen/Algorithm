package interview;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


class Solution {
	public static int[] getKthMostFrequent(int[] nums, int k) {
        Map<Integer, Integer> map = new HashMap<Integer, Integer>();
        for(int i = 0; i < nums.length; i++) {
            int temp = nums[i];
            if(map.containsKey(temp)) {
                int value = map.get(temp);
                map.put(temp, value + 1);
            } else {
                map.put(temp, 1);
            }
        }        
        ArrayList<Integer> values = new ArrayList<Integer>(
                map.values());
        Collections.sort(values);
        Collections.reverse(values);
        
        int[] result = new int[k];
        int count = 0;
        for(int value : values) {
	        for (Map.Entry<Integer, Integer> e : map.entrySet()) {
	        	if (value == e.getValue()) {
	                result[count] = e.getKey();
	                count++;
	                if(count == k) {
	                	return result;
	                }
	        	}
	        }
        }
        return result; 
  } 
    
  public static void main(String[] args) {
	  int[] a = {3,3,3,3,3,5,10,10,10,11,11,11,11,11,11,44,100,102,102,102, 102, 102};
	  int[] result = getKthMostFrequent(a, 3);
      for(int num : result) {
            System.out.print(num + " ");
        }
  }
}

