package interview;

public class tunein_1 {
	
	
	public static void main(String[] args) {
		
	}
}
